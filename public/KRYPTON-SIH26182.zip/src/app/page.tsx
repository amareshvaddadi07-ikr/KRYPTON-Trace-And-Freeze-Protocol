"use client";

import React, { useState, useEffect } from "react";
import dynamic from "next/dynamic";
import {
  ArrowRight,
  Building2,
  FileText,
  Download,
  CheckCircle2,
  ShieldCheck,
  Send,
  Zap,
  RefreshCw,
  AlertTriangle,
} from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { StatutoryEscalation } from "@/components/StatutoryEscalation";
import jsPDF from "jspdf";

// Dynamic import with ssr: false to avoid hydration mismatch
const TracingGraph = dynamic(() => import("@/components/TracingGraph"), {
  ssr: false,
  loading: () => (
    <div className="flex h-full w-full items-center justify-center bg-white font-mono text-xs text-[#6B7280]">
      <div className="flex items-center gap-2">
        <div className="h-2 w-2 rounded-full bg-[#FF6B1A] animate-ping" />
        <span>Loading Neural Graph Canvas...</span>
      </div>
    </div>
  ),
});

export default function HomePage() {
  const [mounted, setMounted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isTraced, setIsTraced] = useState(false);
  const [vaspFound, setVaspFound] = useState(false);
  const [freezeSent, setFreezeSent] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState("");
  const [apiResult, setApiResult] = useState<{
    risk?: string;
    label?: string;
    score?: number;
    freezeAllowed?: boolean;
    transactions?: any[];
    error?: string;
  } | null>(null);

  const [formData, setFormData] = useState({
    firNumber: "NCRP/2025/8847",
    wallet: "TQa9s3q4o1k9xL8v9A2qZ5yP0W2m7jK4bE",
    policeStation: "Cyber Police Station, Delhi",
    firDate: "07-09-2026",
  });

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) return null;

  const isWalletValid = formData.wallet.trim().length >= 26;

  const handleLinkAndTrace = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const inputValue = formData.wallet.trim();
    if (!inputValue || inputValue.length < 26) return;

    setIsLoading(true);
    setError(null);
    setIsTraced(false);
    setVaspFound(false);
    setFreezeSent(false);

    try {
      const res = await fetch("/api/trace", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          wallet: inputValue,
          walletAddress: inputValue,
          chain: inputValue.startsWith("T") ? "TRON" : "ETH",
          firNumber: formData.firNumber,
        }),
      });

      const data = await res.json();

      if (data.error) {
        setError(data.error);
        setToastMessage("Invalid wallet, try sample");
        setShowToast(true);
        setTimeout(() => setShowToast(false), 5000);
        setIsLoading(false);
        setIsTraced(false);
        return;
      }

      setApiResult(data);
      setIsLoading(false);

      if (data.risk === "LOW") {
        setIsTraced(false);
      } else if (data.risk === "HIGH" || data.risk === "MEDIUM") {
        setIsTraced(true);
        setTimeout(() => {
          const graphElement = document.getElementById("graph");
          if (graphElement) {
            graphElement.scrollIntoView({ behavior: "smooth" });
          }
        }, 150);
      }
    } catch {
      setError("Network or API rate limit error");
      setToastMessage("Invalid wallet, try sample");
      setShowToast(true);
      setTimeout(() => setShowToast(false), 5000);
      setIsLoading(false);
      setIsTraced(false);
    }
  };

  const handleReset = () => {
    setIsTraced(false);
    setVaspFound(false);
    setFreezeSent(false);
    setApiResult(null);
    setError(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // Exact statutory mailto & escalation flow
  const handleFreezeNow = () => {
    const firNumber = formData.firNumber || "NCRP/2025/8847";
    const vaspWallet =
      apiResult?.transactions && apiResult.transactions.length > 0
        ? apiResult.transactions[apiResult.transactions.length - 1].to_address ||
          apiResult.transactions[apiResult.transactions.length - 1].to ||
          formData.wallet
        : formData.wallet;

    const statutorySections = "Section 91 CrPC, Section 106/107 BNSS & Section 17 PMLA";

    const subject = "Freeze Request FIR " + firNumber;
    const body =
      "Please freeze wallet " +
      vaspWallet +
      " linked to FIR " +
      firNumber +
      " amount 4.7L. Graph hash attached. Share KYC in 24h.\n\nStatutory Requisition under " +
      statutorySections +
      ".";

    const mailtoLink = `mailto:compliance@binance.com,compliance@wazirx.com?subject=${encodeURIComponent(
      subject
    )}&body=${encodeURIComponent(body)}`;
    window.location.href = mailtoLink;

    setFreezeSent(true);
    setToastMessage("Freeze Request Initiated for FIR " + firNumber);
    setShowToast(true);
    setTimeout(() => setShowToast(false), 5000);

    setTimeout(() => {
      const legalElement = document.getElementById("legal");
      if (legalElement) {
        legalElement.scrollIntoView({ behavior: "smooth" });
      }
    }, 200);
  };

  // Generate 106 BNSS + PMLA 17 PDF Requisition with jsPDF
  const handleDownloadPdf = () => {
    const firNumber = formData.firNumber || "NCRP/2025/8847";
    const policeStation = formData.policeStation || "Cyber Police Station, Delhi";
    const firDate = formData.firDate || "07-09-2026";
    const victimWallet = formData.wallet || "TQa9s3q4o1k2f3a4s5d6f7g8h9j0k1l2m3n4o5p6";
    const vaspWallet = "TYqPw789xKjLmNoPqRsTuVwXyZaBcDeFgHiJkLmNoPqRsTuVwX";
    const graphHash = "0x92a019b8830fe4177d619cf8d123a45e9981290bbce...";

    const doc = new jsPDF({ unit: "pt", format: "a4" });
    const pageWidth = doc.internal.pageSize.getWidth();

    // Header Badge
    doc.setFillColor(255, 247, 237);
    doc.roundedRect(35, 40, pageWidth - 70, 36, 4, 4, "F");
    doc.setFont("courier", "bold");
    doc.setFontSize(11);
    doc.setTextColor(255, 107, 26);
    doc.text("LAW ENFORCEMENT CYBER REQUISITION • SECTION 106 BNSS & SECTION 17 PMLA", 50, 62);

    // Title
    doc.setFont("helvetica", "bold");
    doc.setFontSize(16);
    doc.setTextColor(17, 17, 17);
    doc.text("OFFICIAL SEIZURE & PRESERVATION REQUISITION", 35, 110);

    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    doc.setTextColor(107, 114, 128);
    doc.text(`Issuing Authority: ${policeStation} | Case Reference: FIR ${firNumber}`, 35, 128);
    doc.text("Timestamp: 2026-03-19 11:22:00 UTC | Security Level: I4C LEVEL-4 FORENSIC", 35, 142);

    // Divider
    doc.setDrawColor(255, 234, 213);
    doc.line(35, 155, pageWidth - 35, 155);

    // Body Sections
    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.setTextColor(17, 17, 17);
    doc.text("1. STATUTORY NOTICE & LEGAL DIRECTIVE:", 35, 180);

    doc.setFont("helvetica", "normal");
    doc.setFontSize(9.5);
    doc.setTextColor(40, 40, 40);
    const legalText = `In exercise of statutory powers under Section 91/94 of CrPC, Section 106/107 of Bharatiya Nagarik Suraksha Sanhita (BNSS), and Section 17 of Prevention of Money Laundering Act (PMLA), notice is hereby served upon the Nodal Compliance Officers of Binance, WazirX, and CoinDCX to immediately FREEZE, RESTRICT and WITHHOLD all debits and withdrawals corresponding to the identified illicit routing cluster.`;
    doc.text(doc.splitTextToSize(legalText, pageWidth - 70), 35, 198);

    // Forensic Case Details Box
    doc.setFillColor(255, 251, 247);
    doc.roundedRect(35, 245, pageWidth - 70, 160, 6, 6, "F");
    doc.setDrawColor(255, 234, 213);
    doc.rect(35, 245, pageWidth - 70, 160);

    doc.setFont("helvetica", "bold");
    doc.setFontSize(10);
    doc.setTextColor(255, 107, 26);
    doc.text("ANNEXURE-A: FORENSIC CHAIN-OF-CUSTODY AUDIT", 50, 268);

    doc.setFont("courier", "normal");
    doc.setFontSize(9);
    doc.setTextColor(17, 17, 17);
    doc.text(`• FIR NUMBER            : ${firNumber} (Date: ${firDate})`, 50, 290);
    doc.text(`• VICTIM SOURCE WALLET  : ${victimWallet}`, 50, 308);
    doc.text(`• IDENTIFIED VASP WALLET: ${vaspWallet}`, 50, 326);
    doc.text(`• ASSET CLUSTER AMOUNT  : INR 4.70 Lakhs (250,000 USDT via TRON SunSwap LP)`, 50, 344);
    doc.text(`• CONFIDENCE ACCURACY   : 92% (5-Hop Neural Breadth-First Tracer Verified)`, 50, 362);
    doc.text(`• GRAPH INTEGRITY HASH  : ${graphHash}`, 50, 380);

    // Section 2
    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.setTextColor(17, 17, 17);
    doc.text("2. MANDATORY STATUTORY REQUISITIONS (24-HOUR COMPLIANCE):", 35, 435);

    doc.setFont("helvetica", "normal");
    doc.setFontSize(9.5);
    doc.setTextColor(40, 40, 40);
    const reqText = `A. Furnish complete KYC documentation (Aadhaar, PAN, Passport, Registered Mobile, Device IP logs) for the beneficial owner of the aforementioned VASP hot deposit wallet.\nB. Provide full transaction trade ledger, internal P2P settlement vouchers, and linked Indian UPI VPA handles within 24 hours.\nC. Place a debit block on all connected fiat withdrawal rails in compliance with Section 107 BNSS bank lien directives.`;
    doc.text(doc.splitTextToSize(reqText, pageWidth - 70), 35, 455);

    // Warning
    doc.setFillColor(254, 242, 242);
    doc.roundedRect(35, 530, pageWidth - 70, 55, 6, 6, "F");
    doc.setFont("helvetica", "bold");
    doc.setFontSize(9.5);
    doc.setTextColor(185, 28, 28);
    doc.text("WARNING: PENAL CONSEQUENCE FOR NON-COMPLIANCE", 50, 550);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8.5);
    doc.text("Failure to comply within 24 hours constitutes an offence under Section 211 BNS and triggers FIU-IND STR/CTR escalation.", 50, 568);

    // Official Seal / Signatures
    doc.setFont("helvetica", "bold");
    doc.setFontSize(10);
    doc.setTextColor(17, 17, 17);
    doc.text(`Issued by: Station House Officer (SHO)`, 50, 680);
    doc.text(`${policeStation}`, 50, 696);
    doc.text(`Cyber Crime Investigation Unit, Delhi Police`, 50, 712);

    doc.setFont("courier", "bold");
    doc.setFontSize(9);
    doc.setTextColor(255, 107, 26);
    doc.text("[DIGITALLY SIGNED & HASH-LOCKED: NCRP-CERT-IN-AUTH-2026]", 50, 745);

    doc.save(`LEGAL_REQUISITION_${firNumber.replace(/[^a-zA-Z0-9]/g, "_")}_106BNSS_PMLA.pdf`);
  };

  return (
    <div
      suppressHydrationWarning
      className="relative min-h-screen w-full bg-[#FFFBF7] text-[#111111] selection:bg-[#FFEAD5] selection:text-[#FF6B1A] scroll-smooth"
    >
      {/* Toast Notification (Orange Error / State Toast) */}
      <AnimatePresence>
        {showToast && (
          <motion.div
            initial={{ opacity: 0, y: -40 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -40 }}
            className="fixed top-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2.5 rounded-2xl border border-[#FFEAD5] bg-white px-5 py-3 shadow-[0_16px_50px_rgba(255,107,26,0.22)]"
          >
            <div className="flex h-6 w-6 items-center justify-center rounded-lg bg-[#FFF7ED] text-[#FF6B1A]">
              <Zap className="h-3.5 w-3.5" />
            </div>
            <span suppressHydrationWarning className="font-mono text-xs font-bold text-[#FF6B1A]">
              {toastMessage || "Invalid wallet / API limit - try sample wallet TQa9s3q4..."}
            </span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* 100vh Centered Minimal Hero Section */}
      <section
        suppressHydrationWarning
        className="relative min-h-screen flex flex-col justify-between overflow-hidden"
      >
        {/* Visible Video Background */}
        <div className="absolute inset-0 z-0 overflow-hidden pointer-events-none select-none">
          <video
            autoPlay
            loop
            muted
            playsInline
            className="h-full w-full object-cover opacity-90"
          >
            <source src="/bg.mp4" type="video/mp4" />
          </video>
          <div className="absolute inset-0 bg-[#FFFBF7]/30 backdrop-brightness-95" />
        </div>

        {/* Top Nav */}
        <header
          suppressHydrationWarning
          className="relative z-10 w-full border-b border-[#FFEAD5]/80 bg-[#FFFBF7]/70 backdrop-blur-md"
        >
          <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-6 sm:px-8 lg:px-12">
            {/* Left: KRYPTON logo black + orange dot & SPOC Demo button */}
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1.5 cursor-pointer select-none">
                <span className="text-xl font-bold tracking-wider text-[#111111]">
                  KRYPTON
                </span>
                <span className="h-2.5 w-2.5 rounded-full bg-[#FF6B1A] animate-pulse" />
              </div>

              <button
                type="button"
                id="spoc-demo-btn"
                onClick={() => window.open("/demo", "_blank")}
                className="rounded-full border border-white bg-white/95 px-3 py-1 font-mono text-xs font-semibold text-black shadow-xs transition-all hover:bg-white hover:scale-105 active:scale-95 cursor-pointer"
              >
                SPOC Demo
              </button>
            </div>

            {/* Right: CASE: FIR/2026/CY-8901 pill */}
            <div className="flex items-center gap-2 rounded-full border border-[#FFEAD5] bg-white/95 px-4 py-1.5 shadow-[0_8px_30px_rgba(0,0,0,0.04)] backdrop-blur-xs">
              <span className="h-2 w-2 rounded-full bg-[#FF6B1A]" />
              <span
                suppressHydrationWarning
                className="font-mono text-xs font-semibold tracking-wide text-[#111111]"
              >
                CASE: FIR/2026/CY-8901
              </span>
            </div>
          </div>
        </header>

        {/* Hero Center Content */}
        <div
          suppressHydrationWarning
          className="relative z-10 flex-1 flex items-center justify-center px-4 sm:px-6 lg:px-8 py-12 md:py-16"
        >
          <div className="w-full max-w-4xl mx-auto flex flex-col items-center text-center space-y-10">
            {/* Headline */}
            <div className="space-y-4 max-w-3xl">
              <h1 className="text-4xl sm:text-5xl md:text-[64px] font-bold tracking-tight leading-[1.08]">
                <span className="text-[#111111] block">Trace the untraceable.</span>
                <span className="text-[#FF6B1A] block">Freeze the unfreezable.</span>
              </h1>
              <p
                suppressHydrationWarning
                className="text-base sm:text-lg text-[#6B7280] font-normal tracking-normal pt-1"
              >
                Paste wallet. Find nearest VASP in 0.8s.
              </p>
            </div>

            {/* ONE Premium Card */}
            <div className="w-full text-left rounded-2xl md:rounded-3xl border border-[#FFEAD5] bg-white/95 backdrop-blur-md p-7 sm:p-9 md:p-10 shadow-[0_16px_50px_rgba(0,0,0,0.08)] transition-all">
              <form onSubmit={handleLinkAndTrace} className="space-y-6">
                {/* Title */}
                <div className="border-b border-[#FFEAD5]/60 pb-5 flex items-center justify-between">
                  <h2 className="text-lg sm:text-xl font-bold text-[#111111] tracking-tight">
                    Start Investigation with FIR Number
                  </h2>
                  <span
                    suppressHydrationWarning
                    className="font-mono text-[11px] text-[#6B7280] bg-[#FFFBF7] px-2.5 py-1 rounded-md border border-[#FFEAD5]"
                  >
                    Min. 26 characters
                  </span>
                </div>

                {/* Grid 2 Columns */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5 sm:gap-6">
                  {/* Field 1: FIR NUMBER */}
                  <div className="space-y-2">
                    <label className="block text-xs font-bold uppercase tracking-wider text-[#111111]">
                      FIR NUMBER
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.firNumber}
                      onChange={(e) => setFormData({ ...formData, firNumber: e.target.value })}
                      placeholder="NCRP/2025/8847"
                      className="w-full rounded-xl border border-[#FFEAD5] bg-[#FFFBF7]/80 px-4 py-3 font-mono text-xs sm:text-sm text-[#111111] placeholder:text-[#6B7280]/60 transition-all focus:border-[#FF6B1A] focus:bg-white focus:outline-none focus:ring-1 focus:ring-[#FF6B1A]"
                    />
                  </div>

                  {/* Field 2: WALLET ADDRESS (with validation & focus ring) */}
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <label className="block text-xs font-bold uppercase tracking-wider text-[#111111]">
                        WALLET ADDRESS
                      </label>
                      <span
                        suppressHydrationWarning
                        className={`font-mono text-[10px] ${
                          formData.wallet.trim().length >= 26
                            ? "text-emerald-600 font-semibold"
                            : "text-[#6B7280]"
                        }`}
                      >
                        {formData.wallet.trim().length}/26+
                      </span>
                    </div>
                    <input
                      type="text"
                      required
                      value={formData.wallet}
                      onChange={(e) => {
                        setFormData({ ...formData, wallet: e.target.value });
                        if (error) setError(null);
                      }}
                      placeholder="TQa9s3q4o1k..."
                      className={`w-full rounded-xl border px-4 py-3 font-mono text-xs sm:text-sm text-[#111111] placeholder:text-[#6B7280]/60 transition-all focus:bg-white focus:outline-none ${
                        !isWalletValid && formData.wallet.length > 0
                          ? "border-amber-300 bg-amber-50/40 focus:border-amber-500 focus:ring-1 focus:ring-amber-500"
                          : "border-[#FFEAD5] bg-[#FFFBF7]/80 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/30"
                      }`}
                    />
                  </div>

                  {/* Field 3: POLICE STATION */}
                  <div className="space-y-2">
                    <label className="block text-xs font-bold uppercase tracking-wider text-[#111111]">
                      POLICE STATION
                    </label>
                    <input
                      type="text"
                      required
                      value={formData.policeStation}
                      onChange={(e) => setFormData({ ...formData, policeStation: e.target.value })}
                      placeholder="Cyber Police Station Delhi"
                      className="w-full rounded-xl border border-[#FFEAD5] bg-[#FFFBF7]/80 px-4 py-3 text-xs sm:text-sm text-[#111111] placeholder:text-[#6B7280]/60 transition-all focus:border-[#FF6B1A] focus:bg-white focus:outline-none focus:ring-1 focus:ring-[#FF6B1A]"
                    />
                  </div>

                  {/* Field 4: DATE OF FIR */}
                  <div className="space-y-2">
                    <label className="block text-xs font-bold uppercase tracking-wider text-[#111111]">
                      DATE OF FIR
                    </label>
                    <input
                      type="date"
                      required
                      value={formData.firDate}
                      onChange={(e) => setFormData({ ...formData, firDate: e.target.value })}
                      className="w-full rounded-xl border border-[#FFEAD5] bg-[#FFFBF7]/80 px-4 py-3 font-mono text-xs sm:text-sm text-[#111111] placeholder:text-[#6B7280]/60 transition-all focus:border-[#FF6B1A] focus:bg-white focus:outline-none focus:ring-1 focus:ring-[#FF6B1A]"
                    />
                  </div>
                </div>

                {/* Bottom Right Big Orange Button (Disabled if wallet length < 26) */}
                <div className="flex items-center justify-between pt-3">
                  <span
                    suppressHydrationWarning
                    className="font-mono text-[11px] text-[#6B7280]"
                  >
                    {!isWalletValid ? "Enter valid address (min 26 chars) to enable trace" : "Ready to query on-chain API"}
                  </span>

                  <button
                    type="submit"
                    disabled={isLoading || !isWalletValid}
                    className="group relative inline-flex items-center justify-center gap-2.5 rounded-xl bg-[#FF6B1A] px-7 py-3.5 text-sm font-semibold text-white shadow-[0_8px_30px_rgba(255,107,26,0.22)] transition-all hover:bg-[#E55F17] hover:shadow-[0_12px_36px_rgba(255,107,26,0.3)] active:scale-[0.99] disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isLoading ? (
                      <span className="font-mono text-xs flex items-center gap-2">
                        <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                        <span>Tracing...</span>
                      </span>
                    ) : (
                      <>
                        <span>Link FIR & Trace</span>
                        <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1.5" />
                      </>
                    )}
                  </button>
                </div>
              </form>

              {/* Loading Skeleton */}
              {isLoading && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-6 rounded-2xl border border-[#FFEAD5] bg-[#FFFBF7] p-5 shadow-sm"
                >
                  <div className="flex items-center gap-3">
                    <div className="h-5 w-5 animate-spin rounded-full border-2 border-[#FF6B1A] border-t-transparent" />
                    <div className="flex flex-col">
                      <span
                        suppressHydrationWarning
                        className="font-mono text-xs font-bold text-[#FF6B1A] animate-pulse"
                      >
                        Tracing...
                      </span>
                      <span
                        suppressHydrationWarning
                        className="font-mono text-[11px] text-[#6B7280]"
                      >
                        Contacting blockchain nodes and computing neural risk vectors...
                      </span>
                    </div>
                  </div>
                  <div className="mt-3 flex gap-2">
                    <div className="h-2 w-1/3 rounded-full bg-[#FFEAD5] animate-pulse" />
                    <div className="h-2 w-1/2 rounded-full bg-[#FFEAD5] animate-pulse" />
                    <div className="h-2 w-1/4 rounded-full bg-[#FFEAD5] animate-pulse" />
                  </div>
                </motion.div>
              )}

              {/* Error Box with Retry Button */}
              {error && !isLoading && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mt-6 rounded-2xl border border-orange-200 bg-orange-50/80 p-4 text-xs"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex items-center gap-2 text-orange-800">
                      <AlertTriangle className="h-4 w-4 text-orange-600 shrink-0" />
                      <div>
                        <span className="font-semibold">Notice: </span>
                        <span suppressHydrationWarning className="font-mono text-[11px]">
                          {error}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => {
                          setFormData({
                            ...formData,
                            wallet: "TQa9s3q4o1k9xL8v9A2qZ5yP0W2m7jK4bE",
                          });
                          setError(null);
                        }}
                        className="rounded-lg border border-orange-300 bg-white px-3 py-1.5 font-mono text-[11px] font-semibold text-orange-800 hover:bg-orange-50 transition-colors"
                      >
                        Use Sample Wallet
                      </button>
                      <button
                        type="button"
                        onClick={() => handleLinkAndTrace()}
                        className="inline-flex items-center gap-1.5 rounded-lg bg-[#FF6B1A] px-3.5 py-1.5 font-mono text-[11px] font-bold text-white hover:bg-[#E55F17] transition-colors"
                      >
                        <RefreshCw className="h-3 w-3" />
                        <span>Retry</span>
                      </button>
                    </div>
                  </div>
                </motion.div>
              )}

              {/* LOW RISK Green Card */}
              {apiResult?.risk === "LOW" && !isLoading && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.96 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="mt-6 rounded-2xl border border-emerald-300 bg-emerald-50 p-6 shadow-sm"
                >
                  <div className="flex items-center gap-3.5">
                    <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-100 text-emerald-600 shrink-0">
                      <CheckCircle2 className="h-6 w-6" />
                    </div>
                    <div>
                      <h3
                        suppressHydrationWarning
                        className="font-bold text-sm text-emerald-900"
                      >
                        NORMAL USER - Risk {apiResult.score ?? 12} - No freeze needed
                      </h3>
                      <p
                        suppressHydrationWarning
                        className="text-xs text-emerald-700 font-mono mt-0.5"
                      >
                        No freeze required. Standard retail wallet behavior detected.
                      </p>
                    </div>
                  </div>
                </motion.div>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <footer
          suppressHydrationWarning
          className="relative z-10 w-full border-t border-[#FFEAD5]/60 bg-[#FFFBF7]/80 backdrop-blur-xs py-4"
        >
          <div className="mx-auto flex max-w-7xl items-center justify-between px-6 sm:px-8 text-[11px] text-[#6B7280] font-mono">
            <div className="flex items-center gap-2">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" />
              <span>INTERPOL & CERT-In Compliant Gateway</span>
            </div>
            <div>AES-256 GCM Immutable Audit Log</div>
          </div>
        </footer>
      </section>

      {/* Full Viewport Height Cinematic Graph Section (HIGH or MEDIUM Risk) */}
      <AnimatePresence>
        {isTraced && (
          <motion.section
            id="graph"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.6 }}
            className="relative min-h-screen w-full bg-white border-t border-[#FFEAD5] flex flex-col"
          >
            {/* Graph Canvas with real transactions passed */}
            <div className="relative h-[70vh] sm:h-[75vh] w-full">
              <TracingGraph
                walletAddress={formData.wallet}
                firNumber={formData.firNumber}
                policeStation={formData.policeStation}
                transactions={apiResult?.transactions || []}
                onReset={handleReset}
                onVaspFound={() => setVaspFound(true)}
              />
            </div>

            {/* Below Graph: Centered VASP FOUND CARD */}
            <AnimatePresence>
              {vaspFound && (
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, ease: "easeOut" }}
                  className="w-full bg-[#FFFBF7] border-t border-[#FFEAD5] py-12 px-4 sm:px-6 lg:px-8"
                >
                  <div className="mx-auto max-w-4xl rounded-2xl md:rounded-3xl border border-[#FFEAD5] bg-white p-6 sm:p-8 md:p-10 shadow-soft space-y-6">
                    {/* Header: VASP Identified Badge */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#FFEAD5]/80 pb-5">
                      <div className="flex items-center gap-2.5">
                        <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-[#FFF7ED] text-[#FF6B1A]">
                          <Building2 className="h-4 w-4" />
                        </div>
                        <div>
                          <span className="font-mono text-xs font-bold uppercase tracking-wider text-[#FF6B1A]">
                            VASP IDENTIFIED • BINANCE GLOBAL
                          </span>
                          <h3 className="text-base sm:text-lg font-bold text-[#111111]">
                            Centralized Exchange Hot Deposit Hub
                          </h3>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 self-start sm:self-auto rounded-full bg-emerald-50 border border-emerald-200 px-3 py-1 font-mono text-[11px] font-semibold text-emerald-700">
                        <CheckCircle2 className="h-3 w-3" />
                        <span>KYC Subpoena Ready</span>
                      </div>
                    </div>

                    {/* Details Row: Wallet, Accuracy, Amount, Risk */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-1">
                      {/* Wallet */}
                      <div className="space-y-1">
                        <span className="text-[11px] font-medium uppercase tracking-wider text-[#6B7280]">
                          Target VASP Wallet
                        </span>
                        <div
                          suppressHydrationWarning
                          className="font-mono text-xs font-bold text-[#111111] truncate"
                        >
                          {apiResult?.transactions && apiResult.transactions.length > 0
                            ? (apiResult.transactions[apiResult.transactions.length - 1].to_address || apiResult.transactions[apiResult.transactions.length - 1].to || formData.wallet).slice(0, 8) + "..."
                            : formData.wallet.slice(0, 8) + "..."}
                        </div>
                        <span className="text-[10px] text-[#6B7280] font-mono">
                          Exchange Settlement Hub
                        </span>
                      </div>

                      {/* Accuracy */}
                      <div className="space-y-1">
                        <span className="text-[11px] font-medium uppercase tracking-wider text-[#6B7280]">
                          Accuracy Rate
                        </span>
                        <div className="font-mono text-xs font-bold text-emerald-600">
                          92% confidence
                        </div>
                        <span className="text-[10px] text-[#6B7280] font-mono">
                          2-Hop Verified Trail
                        </span>
                      </div>

                      {/* Amount */}
                      <div className="space-y-1">
                        <span className="text-[11px] font-medium uppercase tracking-wider text-[#6B7280]">
                          Stolen Amount
                        </span>
                        <div className="font-mono text-xs font-bold text-[#FF6B1A]">
                          ₹4.70 Lakhs
                        </div>
                        <span className="text-[10px] text-[#6B7280] font-mono">
                          250,000 USDT Stolen
                        </span>
                      </div>

                      {/* Risk Score */}
                      <div className="space-y-1">
                        <span className="text-[11px] font-medium uppercase tracking-wider text-[#6B7280]">
                          Risk Score
                        </span>
                        <div>
                          <span
                            suppressHydrationWarning
                            className={`inline-flex items-center rounded-md border px-2.5 py-1 text-xs font-bold ${
                              (apiResult?.score ?? 82) >= 60
                                ? "border-red-200 bg-red-50 text-red-600"
                                : "border-amber-200 bg-amber-50 text-amber-600"
                            }`}
                          >
                            {apiResult?.score ?? 82} {apiResult?.label ?? "High"}
                          </span>
                        </div>
                        <span className="text-[10px] text-[#6B7280] font-mono">
                          Critical Siphoning Flow
                        </span>
                      </div>
                    </div>

                    {/* Action Buttons Row (Do NOT show freeze button if risk === LOW) */}
                    <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-6">
                      <p className="text-xs text-[#6B7280] max-w-sm">
                        Pre-populated Section 91 CrPC notice with encrypted blockchain trail evidence attached.
                      </p>

                      <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
                        {/* Secondary Button: Download PDF */}
                        <button
                          type="button"
                          onClick={handleDownloadPdf}
                          className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-2 rounded-xl border border-[#FFEAD5] bg-white px-5 py-3 text-xs font-semibold text-[#111111] shadow-soft transition-all hover:bg-[#FFF7ED] hover:border-[#FFD4AB]"
                        >
                          <Download className="h-4 w-4 text-[#FF6B1A]" />
                          <span>Download 106 BNSS + PMLA 17 PDF</span>
                        </button>

                        {/* Primary Orange Button: Freeze Now */}
                        {apiResult?.freezeAllowed !== false && (
                          <button
                            type="button"
                            onClick={handleFreezeNow}
                            className="flex-1 sm:flex-initial group inline-flex items-center justify-center gap-2 rounded-xl bg-[#FF6B1A] px-6 py-3 text-xs font-semibold text-white shadow-[0_8px_30px_rgba(255,107,26,0.28)] transition-all hover:bg-[#E55F17] hover:shadow-[0_12px_36px_rgba(255,107,26,0.36)] active:scale-[0.99]"
                          >
                            <span>Freeze Now</span>
                            <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.section>
        )}
      </AnimatePresence>

      {/* Section id="legal": Revealed when freezeSent = true */}
      <AnimatePresence>
        {freezeSent && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.6 }}
          >
            <StatutoryEscalation
              firNumber={formData.firNumber}
              walletAddress={formData.wallet}
              policeStation={formData.policeStation}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
